"""
ecdh.py
-------
ECDH key agreement with HKDF-SHA256 key derivation for hybrid encryption.

Role in the hybrid system:
    This module handles the ALTERNATIVE key exchange path to RSA-OAEP.
    Instead of directly encrypting the session key with the recipient's public
    key (as RSA-OAEP does), ECDH works by having two parties independently
    compute the same shared secret through a mathematical key AGREEMENT.
    That shared secret is then fed into HKDF to derive the actual symmetric
    session key. The two code paths are fundamentally different — not
    interchangeable — which is why this is a separate module.

The ECDH flow for messaging (sender side):
    1. Sender generates a FRESH EPHEMERAL key pair for every single message.
    2. Sender performs ECDH between their ephemeral private key and the
       recipient's long-term public key → raw shared secret.
    3. Shared secret is passed through HKDF-SHA256 → 32-byte session key.
    4. Session key is used to encrypt the message (AES-GCM or ChaCha20).
    5. Sender's EPHEMERAL PUBLIC KEY is stored in key_exchange_logs so the
       recipient can reproduce the exact same shared secret.

The ECDH flow for messaging (recipient side):
    1. Recipient retrieves the sender's ephemeral public key from key_exchange_logs.
    2. Recipient performs ECDH between their long-term PRIVATE key and the
       sender's ephemeral public key → same raw shared secret (by math).
    3. Same HKDF-SHA256 pass → same 32-byte session key.
    4. Session key decrypts the message.

Why ephemeral keys per message?
    Using a fresh ephemeral key pair for every message provides
    FORWARD SECRECY: even if the recipient's long-term private key is later
    compromised, past messages cannot be decrypted because the ephemeral
    private key (the other half of the exchange) was never stored and is gone.
    This is a meaningful security property worth noting in the report.

Curve choice — X25519:
    X25519 (Curve25519) is used rather than NIST P-256 (SECP256R1).
    Reasons: purpose-built for Diffie-Hellman, immune to timing side-channels
    by design, no cofactor issues, and recommended by modern standards
    (RFC 7748). The cryptography library provides first-class support.

NOTE on private key storage:
    Long-term user private keys are stored in PEM in SQLite for demo purposes.
    Ephemeral private keys are NEVER stored — they exist only in memory for
    the duration of a single send operation, then are discarded.

Algorithms (all via PyCA cryptography library):
    - Key agreement:    X25519 ECDH
    - Key derivation:   HKDF with SHA-256
    - Derived key size: 32 bytes (256-bit, suitable for AES-256 and ChaCha20)
"""

import os
from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DERIVED_KEY_LENGTH = 32  # 256 bits — works for both AES-256-GCM and ChaCha20
HKDF_INFO = b"secure-messenger-session-key-v1"  # Application-specific context
                                                 # label. Binds derived keys to
                                                 # this application, prevents
                                                 # cross-protocol key reuse.


# ---------------------------------------------------------------------------
# Key Generation
# ---------------------------------------------------------------------------

def generate_x25519_keypair() -> tuple[X25519PrivateKey, X25519PublicKey]:
    """
    Generate a long-term X25519 key pair for a user.

    These are generated ONCE at seed time and stored in the database.
    They are the recipient's stable identity keys — their public key is what
    senders use to initiate the ECDH exchange.

    Returns:
        A (private_key, public_key) tuple of X25519 key objects.
    """
    private_key = X25519PrivateKey.generate()
    public_key = private_key.public_key()
    return private_key, public_key


def generate_ephemeral_keypair() -> tuple[X25519PrivateKey, X25519PublicKey]:
    """
    Generate a fresh ephemeral X25519 key pair for a single message send.

    This is called once per outgoing message and the private key is used
    immediately for key agreement, then DISCARDED. Only the ephemeral PUBLIC
    key is persisted (in key_exchange_logs) so the recipient can reconstruct
    the shared secret.

    Returns:
        A (ephemeral_private_key, ephemeral_public_key) tuple.
    """
    # Functionally identical to generate_x25519_keypair — separated for
    # semantic clarity and to make the code self-documenting.
    private_key = X25519PrivateKey.generate()
    public_key = private_key.public_key()
    return private_key, public_key


# ---------------------------------------------------------------------------
# Serialization — Key <-> PEM/Raw bytes (for DB storage and retrieval)
# ---------------------------------------------------------------------------

def serialize_private_key(private_key: X25519PrivateKey) -> bytes:
    """
    Serialize an X25519 private key to PEM-encoded bytes (unencrypted).

    DEMO SIMPLIFICATION: No encryption passphrase.
    Only long-term user private keys are serialized; ephemeral keys are not.
    """
    return private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


def serialize_public_key(public_key: X25519PublicKey) -> bytes:
    """
    Serialize an X25519 public key to PEM-encoded bytes.

    Used for long-term public keys stored in user_keys table.
    Also used for ephemeral public keys stored in key_exchange_logs.
    """
    return public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )


def serialize_ephemeral_public_key_raw(public_key: X25519PublicKey) -> bytes:
    """
    Serialize an ephemeral public key to raw 32-byte format.

    Raw format is more compact and is the standard wire format for X25519
    public keys (RFC 7748). Used when storing in key_exchange_logs alongside
    a message.
    """
    return public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )


def load_private_key(pem_data: bytes) -> X25519PrivateKey:
    """Deserialize an X25519 private key from PEM bytes."""
    return serialization.load_pem_private_key(pem_data, password=None)


def load_public_key(pem_data: bytes) -> X25519PublicKey:
    """Deserialize an X25519 public key from PEM bytes."""
    return serialization.load_pem_public_key(pem_data)


def load_ephemeral_public_key_raw(raw_bytes: bytes) -> X25519PublicKey:
    """Deserialize an X25519 public key from raw 32-byte format."""
    return X25519PublicKey.from_public_bytes(raw_bytes)


# ---------------------------------------------------------------------------
# HKDF Key Derivation
# ---------------------------------------------------------------------------

def _derive_session_key(shared_secret: bytes, salt: bytes | None = None) -> bytes:
    """
    Derive a fixed-length symmetric session key from the ECDH shared secret.

    The raw ECDH output (shared_secret) is NOT used directly as a key.
    It must be passed through a Key Derivation Function (KDF) first.
    Reasons:
        - The raw shared secret may have non-uniform entropy distribution.
        - HKDF adds domain separation via the 'info' parameter, binding
          the derived key to this specific application context.
        - HKDF with a random salt provides additional security margin.

    Args:
        shared_secret:  Raw bytes from the X25519 exchange operation.
        salt:           Optional random salt bytes. If None, HKDF uses a
                        zero-filled salt of hash length (still secure, but
                        a random salt is preferred where possible).

    Returns:
        32 bytes of derived key material, suitable for AES-256 or ChaCha20.
    """
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=DERIVED_KEY_LENGTH,
        salt=salt,
        info=HKDF_INFO,
    )
    return hkdf.derive(shared_secret)


# ---------------------------------------------------------------------------
# Core ECDH Operations — Sender and Recipient Paths
# ---------------------------------------------------------------------------

def sender_key_exchange(
    recipient_public_key_pem: bytes,
) -> tuple[bytes, bytes, bytes]:
    """
    Perform the SENDER SIDE of the ECDH key exchange.

    Generates a fresh ephemeral key pair, performs the ECDH exchange with the
    recipient's long-term public key, derives the session key via HKDF, and
    returns everything the system needs to encrypt the message and log the
    exchange.

    Args:
        recipient_public_key_pem:  Recipient's long-term X25519 public key
                                   as PEM bytes (retrieved from user_keys DB).

    Returns:
        A tuple of:
            session_key         (bytes) — 32-byte derived key for message encryption
            ephemeral_pub_pem   (bytes) — Ephemeral public key in PEM format,
                                          stored in key_exchange_logs so the
                                          recipient can reproduce the exchange.
            hkdf_salt           (bytes) — Random salt used in HKDF derivation,
                                          also stored so recipient can reproduce.
    """
    # 1. Load recipient's long-term public key
    recipient_pub_key = load_public_key(recipient_public_key_pem)

    # 2. Generate a fresh ephemeral key pair (private key used once, then gone)
    ephemeral_priv, ephemeral_pub = generate_ephemeral_keypair()

    # 3. ECDH key agreement: ephemeral private ⊗ recipient long-term public
    #    → raw shared secret (32 bytes for X25519)
    shared_secret = ephemeral_priv.exchange(recipient_pub_key)

    # 4. Random salt for HKDF — improves security, must be stored for recipient
    hkdf_salt = os.urandom(32)

    # 5. Derive the session key via HKDF-SHA256
    session_key = _derive_session_key(shared_secret, salt=hkdf_salt)

    # 6. Serialize ephemeral public key for storage (PEM for readability in DB)
    ephemeral_pub_pem = serialize_public_key(ephemeral_pub)

    # ephemeral_priv goes out of scope here and is garbage collected.
    # It is never stored anywhere.

    return session_key, ephemeral_pub_pem, hkdf_salt


def recipient_key_exchange(
    recipient_private_key_pem: bytes,
    ephemeral_pub_pem: bytes,
    hkdf_salt: bytes,
) -> bytes:
    """
    Perform the RECIPIENT SIDE of the ECDH key exchange.

    Reproduces the same shared secret and derives the same session key that
    the sender computed, using the recipient's long-term private key and the
    sender's stored ephemeral public key.

    Args:
        recipient_private_key_pem:  Recipient's long-term private key (PEM).
                                    Retrieved from user_keys in the DB.
        ephemeral_pub_pem:          Sender's ephemeral public key (PEM).
                                    Retrieved from key_exchange_logs.
        hkdf_salt:                  Salt used by sender during HKDF derivation.
                                    Retrieved from key_exchange_logs.

    Returns:
        session_key (bytes) — the same 32-byte key the sender derived,
                              ready for message decryption.
    """
    # 1. Load keys from PEM
    recipient_priv_key = load_private_key(recipient_private_key_pem)
    ephemeral_pub_key = load_public_key(ephemeral_pub_pem)

    # 2. ECDH key agreement: recipient long-term private ⊗ sender ephemeral public
    #    → same shared secret (ECDH is commutative by design)
    shared_secret = recipient_priv_key.exchange(ephemeral_pub_key)

    # 3. Reproduce session key with same HKDF parameters
    session_key = _derive_session_key(shared_secret, salt=hkdf_salt)

    return session_key


# ---------------------------------------------------------------------------
# Quick self-test (run this file directly to verify the module works)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import base64

    print("=== ECDH + HKDF Module Self-Test ===\n")

    # 1. Generate long-term key pair for a simulated recipient (Bob)
    bob_priv, bob_pub = generate_x25519_keypair()
    bob_priv_pem = serialize_private_key(bob_priv)
    bob_pub_pem = serialize_public_key(bob_pub)
    print("[1] Bob's long-term X25519 key pair generated and serialized.")

    # 2. Simulate Alice (sender) performing the exchange
    session_key_sender, ephemeral_pub_pem, hkdf_salt = sender_key_exchange(bob_pub_pem)
    print(f"[2] Sender exchange complete.")
    print(f"    Session key (b64): {base64.b64encode(session_key_sender).decode()}")
    print(f"    HKDF salt   (b64): {base64.b64encode(hkdf_salt).decode()}")
    print(f"    Ephemeral pub key stored: {len(ephemeral_pub_pem)} bytes (PEM)")

    # 3. Simulate Bob (recipient) reproducing the session key
    session_key_recipient = recipient_key_exchange(
        bob_priv_pem, ephemeral_pub_pem, hkdf_salt
    )
    print(f"\n[3] Recipient exchange complete.")
    print(f"    Session key (b64): {base64.b64encode(session_key_recipient).decode()}")

    # 4. Verify both sides derived the same key
    assert session_key_sender == session_key_recipient, \
        "KEY MISMATCH — ECDH exchange failed!"
    print("\n[4] Both session keys are identical: MATCH ✓")

    # 5. Verify a second message produces a DIFFERENT ephemeral key and session key
    session_key_msg2, ephemeral_pub_pem_2, hkdf_salt_2 = sender_key_exchange(bob_pub_pem)
    assert session_key_msg2 != session_key_sender, \
        "FORWARD SECRECY FAILURE — same session key generated twice!"
    assert ephemeral_pub_pem_2 != ephemeral_pub_pem, \
        "EPHEMERAL KEY REUSE — same ephemeral key generated twice!"
    print("[5] Second message produces distinct ephemeral key and session key: ✓")
    print("    (Forward secrecy property confirmed.)")

    print("\nAll ECDH + HKDF tests passed.")

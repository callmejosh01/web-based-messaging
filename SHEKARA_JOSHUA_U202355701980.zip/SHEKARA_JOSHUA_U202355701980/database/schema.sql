-- schema.sql
-- ----------
-- SQLite schema for the secure messenger demonstrator.
-- Run once by database.py on first startup.
-- All binary data (keys, ciphertext, nonces, MACs) is stored as
-- base64-encoded TEXT. SQLite has no native BLOB with length guarantees
-- and TEXT is easier to inspect directly in a DB browser during development.

PRAGMA journal_mode=WAL;  -- Write-Ahead Logging: safer concurrent reads
PRAGMA foreign_keys=ON;

-- ---------------------------------------------------------------------------
-- user_keys
-- Stores each pre-seeded user's identity and both key pairs.
-- DEMO NOTE: Storing private keys server-side is a deliberate simplification.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS user_keys (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    username                TEXT NOT NULL UNIQUE,

    -- RSA-OAEP key pair (PEM, base64-free — PEM is already ASCII-safe)
    rsa_public_key_pem      TEXT NOT NULL,
    rsa_private_key_pem     TEXT NOT NULL,

    -- X25519 (ECDH) key pair (PEM)
    ecdh_public_key_pem     TEXT NOT NULL,
    ecdh_private_key_pem    TEXT NOT NULL,

    created_at              TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ---------------------------------------------------------------------------
-- encrypted_messages
-- One row per sent message. Stores everything needed to display the
-- ciphertext blob and to decrypt the message for the intended recipient.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS encrypted_messages (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    sender                  TEXT NOT NULL,
    recipient               TEXT NOT NULL,

    -- The symmetric algorithm used for this message
    -- Values: "AES-GCM" | "ChaCha20-Poly1305"
    symmetric_algo          TEXT NOT NULL,

    -- The key exchange algorithm used for this message
    -- Values: "RSA-OAEP" | "ECDH"
    key_exchange_algo       TEXT NOT NULL,

    -- RSA-OAEP path: the session key encrypted with recipient's RSA public key
    -- ECDH path: NULL (session key is reproduced from key_exchange_logs)
    wrapped_session_key_b64 TEXT,

    -- Nonce/IV used during symmetric encryption (base64)
    -- AES-GCM: 12 bytes | ChaCha20-Poly1305: 16 bytes
    nonce_b64               TEXT NOT NULL,

    -- Ciphertext including the AEAD authentication tag (base64)
    -- This is the raw blob displayed in the UI's left panel
    ciphertext_b64          TEXT NOT NULL,

    -- HMAC-SHA256 over nonce || ciphertext (Encrypt-then-MAC)
    hmac_b64                TEXT NOT NULL,

    timestamp               TEXT NOT NULL DEFAULT (datetime('now')),

    FOREIGN KEY (sender)    REFERENCES user_keys(username),
    FOREIGN KEY (recipient) REFERENCES user_keys(username)
);

-- ---------------------------------------------------------------------------
-- key_exchange_logs
-- One row per sent message using ECDH. Stores the ephemeral public key
-- and HKDF salt so the recipient can reproduce the session key.
-- For RSA-OAEP messages this table has no entry (session key is wrapped
-- directly in encrypted_messages.wrapped_session_key_b64).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS key_exchange_logs (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id              INTEGER NOT NULL UNIQUE,

    -- Sender's ephemeral X25519 public key (PEM, base64-safe ASCII)
    ephemeral_pub_key_pem   TEXT NOT NULL,

    -- HKDF salt used during key derivation (base64)
    hkdf_salt_b64           TEXT NOT NULL,

    logged_at               TEXT NOT NULL DEFAULT (datetime('now')),

    FOREIGN KEY (message_id) REFERENCES encrypted_messages(id)
        ON DELETE CASCADE
);

-- Indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_messages_recipient
    ON encrypted_messages(recipient);

CREATE INDEX IF NOT EXISTS idx_messages_sender_recipient
    ON encrypted_messages(sender, recipient);

CREATE INDEX IF NOT EXISTS idx_key_exchange_message
    ON key_exchange_logs(message_id);

"""
database.py
-----------
SQLite interface — schema init, user key storage, message persistence,
and all read queries used by Flask routes.

Gotcha — Row factory:
    sqlite3 returns plain tuples by default. Setting row_factory to
    sqlite3.Row gives dict-like access by column name (row["username"])
    which keeps route code readable without an ORM.

Gotcha — Thread safety:
    SQLite connections are not thread-safe. Flask's dev server is
    single-threaded, but to be safe each call opens and closes its own
    connection. check_same_thread=False is set because Flask may call
    from different threads in some configurations.
"""

import sqlite3
import os
from pathlib import Path


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DB_PATH     = Path(__file__).parent.parent / "messenger.db"
SCHEMA_PATH = Path(__file__).parent / "schema.sql"


# ---------------------------------------------------------------------------
# Connection helper
# ---------------------------------------------------------------------------

def get_connection() -> sqlite3.Connection:
    """Open a new SQLite connection with Row factory enabled."""
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


# ---------------------------------------------------------------------------
# Schema initialisation
# ---------------------------------------------------------------------------

def init_db() -> None:
    """
    Run schema.sql against the database if tables don't already exist.
    Called once at application startup before seeding.
    """
    schema_sql = SCHEMA_PATH.read_text()
    with get_connection() as conn:
        conn.executescript(schema_sql)
    print(f"[DB] Schema initialised at {DB_PATH}")


# ---------------------------------------------------------------------------
# User / Key operations
# ---------------------------------------------------------------------------

def user_exists(username: str) -> bool:
    """Return True if username already has a row in user_keys."""
    with get_connection() as conn:
        row = conn.execute(
            "SELECT 1 FROM user_keys WHERE username = ?", (username,)
        ).fetchone()
    return row is not None


def insert_user_keys(
    username: str,
    rsa_public_pem: str,
    rsa_private_pem: str,
    ecdh_public_pem: str,
    ecdh_private_pem: str,
) -> None:
    """
    Insert a new user with both RSA and ECDH key pairs.
    PEM values are passed as strings (PEM is ASCII-safe).
    """
    with get_connection() as conn:
        conn.execute(
            """
            INSERT INTO user_keys
                (username, rsa_public_key_pem, rsa_private_key_pem,
                 ecdh_public_key_pem, ecdh_private_key_pem)
            VALUES (?, ?, ?, ?, ?)
            """,
            (username, rsa_public_pem, rsa_private_pem,
             ecdh_public_pem, ecdh_private_pem),
        )


def get_user_keys(username: str) -> sqlite3.Row | None:
    """
    Retrieve all stored key material for a user.

    Returns a Row with columns:
        username, rsa_public_key_pem, rsa_private_key_pem,
        ecdh_public_key_pem, ecdh_private_key_pem
    Returns None if the user does not exist.
    """
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM user_keys WHERE username = ?", (username,)
        ).fetchone()


def get_all_usernames() -> list[str]:
    """Return a list of all seeded usernames."""
    with get_connection() as conn:
        rows = conn.execute("SELECT username FROM user_keys ORDER BY username").fetchall()
    return [row["username"] for row in rows]


# ---------------------------------------------------------------------------
# Message persistence
# ---------------------------------------------------------------------------

def insert_message(
    sender: str,
    recipient: str,
    symmetric_algo: str,
    key_exchange_algo: str,
    nonce_b64: str,
    ciphertext_b64: str,
    hmac_b64: str,
    wrapped_session_key_b64: str | None = None,
) -> int:
    """
    Insert an encrypted message. Returns the new message row ID.

    wrapped_session_key_b64 is provided for RSA-OAEP messages.
    For ECDH messages it is None — the session key is reproduced via
    key_exchange_logs.
    """
    with get_connection() as conn:
        cursor = conn.execute(
            """
            INSERT INTO encrypted_messages
                (sender, recipient, symmetric_algo, key_exchange_algo,
                 nonce_b64, ciphertext_b64, hmac_b64, wrapped_session_key_b64)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (sender, recipient, symmetric_algo, key_exchange_algo,
             nonce_b64, ciphertext_b64, hmac_b64, wrapped_session_key_b64),
        )
        return cursor.lastrowid


def insert_key_exchange_log(
    message_id: int,
    ephemeral_pub_key_pem: str,
    hkdf_salt_b64: str,
) -> None:
    """
    Insert an ECDH key exchange log entry linked to a message row.
    Called immediately after insert_message for ECDH messages.
    """
    with get_connection() as conn:
        conn.execute(
            """
            INSERT INTO key_exchange_logs
                (message_id, ephemeral_pub_key_pem, hkdf_salt_b64)
            VALUES (?, ?, ?)
            """,
            (message_id, ephemeral_pub_key_pem, hkdf_salt_b64),
        )


# ---------------------------------------------------------------------------
# Message retrieval
# ---------------------------------------------------------------------------

def get_conversation(user_a: str, user_b: str) -> list[sqlite3.Row]:
    """
    Retrieve all messages exchanged between two users, ordered by timestamp.

    Returns rows with all encrypted_messages columns plus (where available)
    the key_exchange_logs columns via LEFT JOIN.
    """
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT
                em.*,
                kel.ephemeral_pub_key_pem,
                kel.hkdf_salt_b64
            FROM encrypted_messages em
            LEFT JOIN key_exchange_logs kel ON kel.message_id = em.id
            WHERE
                (em.sender = ? AND em.recipient = ?)
                OR
                (em.sender = ? AND em.recipient = ?)
            ORDER BY em.timestamp ASC
            """,
            (user_a, user_b, user_b, user_a),
        ).fetchall()
    return rows


def get_message_by_id(message_id: int) -> sqlite3.Row | None:
    """
    Retrieve a single message with its key exchange log (if any).
    Used by the decrypt route.
    """
    with get_connection() as conn:
        return conn.execute(
            """
            SELECT
                em.*,
                kel.ephemeral_pub_key_pem,
                kel.hkdf_salt_b64
            FROM encrypted_messages em
            LEFT JOIN key_exchange_logs kel ON kel.message_id = em.id
            WHERE em.id = ?
            """,
            (message_id,),
        ).fetchone()

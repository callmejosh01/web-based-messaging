"""
symmetric.py
------------
AES-256-GCM and ChaCha20-Poly1305 message encryption/decryption.

Both are AEAD (Authenticated Encryption with Associated Data) ciphers —
confidentiality and integrity are provided in a single operation.
HMAC-SHA256 is still applied on top as an explicit, auditable integrity
layer (Encrypt-then-MAC), but the AEAD tag inside each cipher already
catches accidental corruption independently.

Gotcha — Nonce reuse is catastrophic:
    AES-GCM with a repeated (key, nonce) pair completely breaks
    confidentiality and allows key recovery. os.urandom(12) for every
    encryption call is non-negotiable. ChaCha20 uses a 16-byte nonce
    (XChaCha20 variant is not used here; standard 16-byte is fine for
    random nonces at this message volume).

Gotcha — GCM tag size:
    The cryptography library appends the 16-byte GCM authentication tag
    directly to the ciphertext. When you store the ciphertext blob in SQLite,
    the tag is already included. On decryption the library verifies and strips
    it automatically. Do not manually try to separate them.

Ciphertext layout stored in DB (base64-encoded):
    AES-GCM:          nonce(12B) || ciphertext+tag
    ChaCha20-Poly1305: nonce(12B) || ciphertext+tag
"""

import os
import base64

from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

AES_GCM_NONCE_SIZE     = 12   # 96-bit nonce — NIST recommended for GCM
CHACHA20_NONCE_SIZE    = 12   # 96-bit nonce for ChaCha20-Poly1305
SESSION_KEY_SIZE       = 32   # 256-bit keys for both ciphers


# ---------------------------------------------------------------------------
# AES-256-GCM
# ---------------------------------------------------------------------------

def aes_gcm_encrypt(plaintext: bytes, session_key: bytes) -> tuple[bytes, bytes]:
    """
    Encrypt plaintext using AES-256-GCM.

    Args:
        plaintext:    Raw message bytes.
        session_key:  32-byte symmetric key.

    Returns:
        (ciphertext_with_tag, nonce)
        ciphertext_with_tag: encrypted bytes with 16-byte GCM tag appended.
        nonce:               12-byte random nonce. Must be stored alongside
                             the ciphertext for decryption.
    """
    nonce = os.urandom(AES_GCM_NONCE_SIZE)
    aesgcm = AESGCM(session_key)
    ciphertext_with_tag = aesgcm.encrypt(nonce, plaintext, None)
    return ciphertext_with_tag, nonce


def aes_gcm_decrypt(ciphertext_with_tag: bytes, session_key: bytes, nonce: bytes) -> bytes:
    """
    Decrypt AES-256-GCM ciphertext and verify the authentication tag.

    Raises:
        cryptography.exceptions.InvalidTag: if the tag verification fails,
        meaning the ciphertext has been tampered with or the key/nonce
        combination is wrong. Caller must treat this as a hard failure.
    """
    aesgcm = AESGCM(session_key)
    return aesgcm.decrypt(nonce, ciphertext_with_tag, None)


# ---------------------------------------------------------------------------
# ChaCha20-Poly1305
# ---------------------------------------------------------------------------

def chacha20_encrypt(plaintext: bytes, session_key: bytes) -> tuple[bytes, bytes]:
    """
    Encrypt plaintext using ChaCha20-Poly1305.

    Args:
        plaintext:    Raw message bytes.
        session_key:  32-byte symmetric key.

    Returns:
        (ciphertext_with_tag, nonce)
        ciphertext_with_tag: encrypted bytes with 16-byte Poly1305 tag appended.
        nonce:               16-byte random nonce.
    """
    nonce = os.urandom(CHACHA20_NONCE_SIZE)
    chacha = ChaCha20Poly1305(session_key)
    ciphertext_with_tag = chacha.encrypt(nonce, plaintext, None)
    return ciphertext_with_tag, nonce


def chacha20_decrypt(ciphertext_with_tag: bytes, session_key: bytes, nonce: bytes) -> bytes:
    """
    Decrypt ChaCha20-Poly1305 ciphertext and verify the Poly1305 tag.

    Raises:
        cryptography.exceptions.InvalidTag: on authentication failure.
    """
    chacha = ChaCha20Poly1305(session_key)
    return chacha.decrypt(nonce, ciphertext_with_tag, None)


# ---------------------------------------------------------------------------
# Unified interface — called by Flask routes and benchmark script
# ---------------------------------------------------------------------------

SYMMETRIC_ALGORITHMS = ("AES-GCM", "ChaCha20-Poly1305")


def encrypt_message(plaintext: str, session_key: bytes, algorithm: str) -> tuple[bytes, bytes]:
    """
    Encrypt a plaintext string with the specified symmetric algorithm.

    Args:
        plaintext:    The message string to encrypt.
        session_key:  32-byte key derived from key exchange.
        algorithm:    One of "AES-GCM" or "ChaCha20-Poly1305".

    Returns:
        (ciphertext_with_tag, nonce)
    """
    plaintext_bytes = plaintext.encode("utf-8")

    if algorithm == "AES-GCM":
        return aes_gcm_encrypt(plaintext_bytes, session_key)
    elif algorithm == "ChaCha20-Poly1305":
        return chacha20_encrypt(plaintext_bytes, session_key)
    else:
        raise ValueError(f"Unknown symmetric algorithm: {algorithm!r}")


def decrypt_message(
    ciphertext_with_tag: bytes,
    session_key: bytes,
    nonce: bytes,
    algorithm: str,
) -> str:
    """
    Decrypt a ciphertext blob and return the plaintext string.

    Args:
        ciphertext_with_tag:  Encrypted bytes including authentication tag.
        session_key:          32-byte key reproduced from key exchange.
        nonce:                Nonce stored alongside the ciphertext.
        algorithm:            One of "AES-GCM" or "ChaCha20-Poly1305".

    Returns:
        Decrypted message as a UTF-8 string.

    Raises:
        cryptography.exceptions.InvalidTag: on authentication failure.
        ValueError: on unknown algorithm.
    """
    if algorithm == "AES-GCM":
        plaintext_bytes = aes_gcm_decrypt(ciphertext_with_tag, session_key, nonce)
    elif algorithm == "ChaCha20-Poly1305":
        plaintext_bytes = chacha20_decrypt(ciphertext_with_tag, session_key, nonce)
    else:
        raise ValueError(f"Unknown symmetric algorithm: {algorithm!r}")

    return plaintext_bytes.decode("utf-8")


# ---------------------------------------------------------------------------
# Storage helpers — base64 encoding for SQLite TEXT columns
# ---------------------------------------------------------------------------

def encode_for_storage(data: bytes) -> str:
    """Encode raw bytes to a base64 string for SQLite TEXT storage."""
    return base64.b64encode(data).decode("ascii")


def decode_from_storage(b64_string: str) -> bytes:
    """Decode a base64 string from SQLite back to raw bytes."""
    return base64.b64decode(b64_string.encode("ascii"))

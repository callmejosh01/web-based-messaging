"""
rsa_oaep.py
-----------
RSA-OAEP key wrapping and unwrapping for hybrid encryption.

Role in the hybrid system:
    - Generates RSA key pairs for users (stored once at seed time).
    - Wraps (encrypts) a symmetric session key with the recipient's RSA public key.
    - Unwraps (decrypts) the session key using the recipient's RSA private key.

NOTE on private key storage:
    Private keys are stored unencrypted in PEM format in SQLite for demo
    purposes. This is a deliberate simplification. In production, private keys
    would never leave the client and would never be stored server-side.

Algorithms used (all via PyCA cryptography library):
    - RSA key generation: 2048-bit modulus (minimum acceptable; 4096 optional)
    - Padding: OAEP with MGF1
    - Hash: SHA-256 (used in both OAEP label hash and MGF1)
"""

from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives.asymmetric.rsa import (
    RSAPrivateKey,
    RSAPublicKey,
)
from cryptography.hazmat.primitives import hashes, serialization


# ---------------------------------------------------------------------------
# Key Generation
# ---------------------------------------------------------------------------

def generate_rsa_keypair(key_size: int = 2048) -> tuple[RSAPrivateKey, RSAPublicKey]:
    """
    Generate an RSA key pair.

    Args:
        key_size: RSA modulus size in bits. 2048 is the default.
                  Accepts 2048 or 4096.

    Returns:
        A (private_key, public_key) tuple of RSA key objects.
    """
    private_key = rsa.generate_private_key(
        public_exponent=65537,  # Standard; do not change.
        key_size=key_size,
    )
    public_key = private_key.public_key()
    return private_key, public_key


# ---------------------------------------------------------------------------
# Serialization — Key <-> PEM (for DB storage and retrieval)
# ---------------------------------------------------------------------------

def serialize_private_key(private_key: RSAPrivateKey) -> bytes:
    """
    Serialize an RSA private key to PEM-encoded bytes (unencrypted).

    DEMO SIMPLIFICATION: No encryption passphrase is applied.
    Production systems must never store plaintext private keys.
    """
    return private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


def serialize_public_key(public_key: RSAPublicKey) -> bytes:
    """Serialize an RSA public key to PEM-encoded bytes."""
    return public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )


def load_private_key(pem_data: bytes) -> RSAPrivateKey:
    """Deserialize an RSA private key from PEM bytes."""
    return serialization.load_pem_private_key(pem_data, password=None)


def load_public_key(pem_data: bytes) -> RSAPublicKey:
    """Deserialize an RSA public key from PEM bytes."""
    return serialization.load_pem_public_key(pem_data)


# ---------------------------------------------------------------------------
# Key Wrapping (Encryption of the symmetric session key)
# ---------------------------------------------------------------------------

def wrap_key(session_key: bytes, recipient_public_key: RSAPublicKey) -> bytes:
    """
    Encrypt (wrap) a symmetric session key using the recipient's RSA public key.

    Uses OAEP padding with SHA-256 for both the hash and MGF1 mask function.
    OAEP is semantically secure and is the correct choice over PKCS1v15.

    Args:
        session_key:           The raw symmetric key bytes to protect.
                               For AES-256 this will be 32 bytes.
                               For ChaCha20 this will be 32 bytes.
        recipient_public_key:  The recipient's RSA public key object.

    Returns:
        The RSA-OAEP encrypted session key as raw bytes.
        At 2048-bit RSA this will always be 256 bytes (2048 bits).
    """
    wrapped = recipient_public_key.encrypt(
        session_key,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )
    return wrapped


def unwrap_key(wrapped_key: bytes, recipient_private_key: RSAPrivateKey) -> bytes:
    """
    Decrypt (unwrap) a symmetric session key using the recipient's RSA private key.

    Args:
        wrapped_key:            The RSA-OAEP encrypted session key bytes.
        recipient_private_key:  The recipient's RSA private key object.

    Returns:
        The original raw symmetric session key bytes.

    Raises:
        ValueError: If decryption fails (wrong key, corrupted ciphertext).
    """
    session_key = recipient_private_key.decrypt(
        wrapped_key,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )
    return session_key


# ---------------------------------------------------------------------------
# Convenience: PEM round-trip helpers (used by seed.py and routes)
# ---------------------------------------------------------------------------

def wrap_key_from_pem(session_key: bytes, public_key_pem: bytes) -> bytes:
    """Wrap a session key given the recipient's public key as PEM bytes."""
    public_key = load_public_key(public_key_pem)
    return wrap_key(session_key, public_key)


def unwrap_key_from_pem(wrapped_key: bytes, private_key_pem: bytes) -> bytes:
    """Unwrap a session key given the recipient's private key as PEM bytes."""
    private_key = load_private_key(private_key_pem)
    return unwrap_key(wrapped_key, private_key)


# ---------------------------------------------------------------------------
# Quick self-test (run this file directly to verify the module works)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import os
    import base64

    print("=== RSA-OAEP Module Self-Test ===\n")

    # 1. Generate a key pair
    priv, pub = generate_rsa_keypair(key_size=2048)
    print("[1] RSA-2048 key pair generated.")

    # 2. Serialize and reload (simulates DB round-trip)
    priv_pem = serialize_private_key(priv)
    pub_pem = serialize_public_key(pub)
    priv_reloaded = load_private_key(priv_pem)
    pub_reloaded = load_public_key(pub_pem)
    print("[2] Serialization/deserialization round-trip: OK")

    # 3. Wrap a mock 32-byte AES-256 session key
    mock_session_key = os.urandom(32)
    wrapped = wrap_key_from_pem(mock_session_key, pub_pem)
    print(f"[3] Session key wrapped.  Ciphertext size: {len(wrapped)} bytes")
    print(f"    Wrapped key (b64): {base64.b64encode(wrapped).decode()[:64]}...")

    # 4. Unwrap and verify
    recovered = unwrap_key_from_pem(wrapped, priv_pem)
    assert recovered == mock_session_key, "KEY MISMATCH — unwrap failed!"
    print("[4] Session key unwrapped and verified: MATCH ✓")

    print("\nAll RSA-OAEP tests passed.")

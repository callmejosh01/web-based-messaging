"""
crypto_engine.py
----------------
The orchestration layer. This is the only file Flask routes import for
cryptographic operations. It wires together rsa_oaep, ecdh, symmetric,
and integrity into two clean public functions: encrypt_message and
decrypt_message.

This is where the non-trivial engineering lives:
    - Choosing the right key exchange code path (RSA-OAEP vs ECDH)
    - Deriving a separate HMAC key from the session key
    - Applying Encrypt-then-MAC in the correct order
    - Assembling the data bundle for DB persistence
    - Reassembling the session key from DB data on the decrypt path

Return contract:
    encrypt_message returns a flat dict of base64 strings and metadata
    ready to be passed directly to database.insert_message().

    decrypt_message accepts a sqlite3.Row (or dict-like) from
    database.get_message_by_id() and returns the plaintext string plus
    the HMAC verification status.
"""

import base64

from crypto import rsa_oaep
from crypto import ecdh
from crypto import symmetric
from crypto import integrity


# ---------------------------------------------------------------------------
# Algorithm combo identifiers (must match dropdown values in the template)
# ---------------------------------------------------------------------------

KEY_EXCHANGE_ALGOS = ("RSA-OAEP", "ECDH")
SYMMETRIC_ALGOS    = ("AES-GCM", "ChaCha20-Poly1305")


# ---------------------------------------------------------------------------
# Encrypt path
# ---------------------------------------------------------------------------

def encrypt_message(
    plaintext: str,
    sender: str,
    recipient_row: object,       # sqlite3.Row from database.get_user_keys()
    key_exchange_algo: str,
    symmetric_algo: str,
) -> dict:
    """
    Full encrypt pipeline for a single message.

    Args:
        plaintext:          The message text to encrypt.
        sender:             Username of the sender (stored as metadata).
        recipient_row:      DB row for the recipient containing all key PEMs.
        key_exchange_algo:  "RSA-OAEP" or "ECDH"
        symmetric_algo:     "AES-GCM" or "ChaCha20-Poly1305"

    Returns:
        A dict with keys ready for database.insert_message():
            sender, recipient, symmetric_algo, key_exchange_algo,
            nonce_b64, ciphertext_b64, hmac_b64,
            wrapped_session_key_b64  (str or None),
            ephemeral_pub_key_pem    (str or None),  -- ECDH only
            hkdf_salt_b64            (str or None),  -- ECDH only
    """
    # --- Step 1: Key exchange → session key ---
    ephemeral_pub_pem = None
    hkdf_salt_b64     = None
    wrapped_key_b64   = None

    if key_exchange_algo == "RSA-OAEP":
        # Generate a fresh 32-byte session key, wrap it with recipient's RSA pubkey
        import os
        session_key = os.urandom(32)
        recipient_rsa_pub_pem = recipient_row["rsa_public_key_pem"].encode("ascii")
        wrapped_key = rsa_oaep.wrap_key_from_pem(session_key, recipient_rsa_pub_pem)
        wrapped_key_b64 = symmetric.encode_for_storage(wrapped_key)

    elif key_exchange_algo == "ECDH":
        # Perform ephemeral ECDH against recipient's long-term ECDH public key
        recipient_ecdh_pub_pem = recipient_row["ecdh_public_key_pem"].encode("ascii")
        session_key, _ephemeral_pub_pem_bytes, hkdf_salt = ecdh.sender_key_exchange(
            recipient_ecdh_pub_pem
        )
        ephemeral_pub_pem = _ephemeral_pub_pem_bytes.decode("ascii")
        hkdf_salt_b64     = symmetric.encode_for_storage(hkdf_salt)

    else:
        raise ValueError(f"Unknown key exchange algorithm: {key_exchange_algo!r}")

    # --- Step 2: Symmetric encryption ---
    ciphertext_with_tag, nonce = symmetric.encrypt_message(
        plaintext, session_key, symmetric_algo
    )

    # --- Step 3: HMAC (Encrypt-then-MAC over nonce || ciphertext) ---
    hmac_key = integrity.derive_hmac_key(session_key)
    mac      = integrity.compute_hmac(hmac_key, nonce, ciphertext_with_tag)

    # --- Step 4: Encode everything for storage ---
    return {
        "sender":                  sender,
        "recipient":               recipient_row["username"],
        "symmetric_algo":          symmetric_algo,
        "key_exchange_algo":       key_exchange_algo,
        "nonce_b64":               symmetric.encode_for_storage(nonce),
        "ciphertext_b64":          symmetric.encode_for_storage(ciphertext_with_tag),
        "hmac_b64":                integrity.encode_mac_for_storage(mac),
        "wrapped_session_key_b64": wrapped_key_b64,
        "ephemeral_pub_key_pem":   ephemeral_pub_pem,
        "hkdf_salt_b64":           hkdf_salt_b64,
    }


# ---------------------------------------------------------------------------
# Decrypt path
# ---------------------------------------------------------------------------

def decrypt_message(message_row: object, recipient_row: object) -> dict:
    """
    Full decrypt pipeline for a single message row from the DB.

    Args:
        message_row:    sqlite3.Row from database.get_message_by_id()
                        (includes LEFT JOIN columns from key_exchange_logs).
        recipient_row:  sqlite3.Row from database.get_user_keys() for the
                        intended recipient.

    Returns:
        {
            "plaintext":     str — the decrypted message,
            "hmac_ok":       bool — True if HMAC verified,
            "hmac_status":   str — "✓ Verified" or "✗ Tampered",
        }
    """
    # --- Step 1: Decode stored blobs ---
    nonce               = symmetric.decode_from_storage(message_row["nonce_b64"])
    ciphertext_with_tag = symmetric.decode_from_storage(message_row["ciphertext_b64"])
    stored_mac          = integrity.decode_mac_from_storage(message_row["hmac_b64"])

    key_exchange_algo = message_row["key_exchange_algo"]
    symmetric_algo    = message_row["symmetric_algo"]

    # --- Step 2: Reproduce session key ---
    if key_exchange_algo == "RSA-OAEP":
        wrapped_key = symmetric.decode_from_storage(
            message_row["wrapped_session_key_b64"]
        )
        recipient_rsa_priv_pem = recipient_row["rsa_private_key_pem"].encode("ascii")
        session_key = rsa_oaep.unwrap_key_from_pem(wrapped_key, recipient_rsa_priv_pem)

    elif key_exchange_algo == "ECDH":
        ephemeral_pub_pem = message_row["ephemeral_pub_key_pem"].encode("ascii")
        hkdf_salt         = symmetric.decode_from_storage(message_row["hkdf_salt_b64"])
        recipient_ecdh_priv_pem = recipient_row["ecdh_private_key_pem"].encode("ascii")
        session_key = ecdh.recipient_key_exchange(
            recipient_ecdh_priv_pem, ephemeral_pub_pem, hkdf_salt
        )

    else:
        raise ValueError(f"Unknown key exchange algorithm: {key_exchange_algo!r}")

    # --- Step 3: HMAC verification (before decryption — Encrypt-then-MAC) ---
    hmac_key = integrity.derive_hmac_key(session_key)
    hmac_ok  = integrity.verify_hmac(hmac_key, nonce, ciphertext_with_tag, stored_mac)
    hmac_status = "✓ Verified" if hmac_ok else "✗ Tampered"

    # --- Step 4: Decrypt ---
    try:
        plaintext = symmetric.decrypt_message(
            ciphertext_with_tag, session_key, nonce, symmetric_algo
        )
    except Exception:
        # AEAD tag verification failed — ciphertext is corrupt or tampered
        plaintext = "[Decryption failed — ciphertext integrity check failed]"

    return {
        "plaintext":   plaintext,
        "hmac_ok":     hmac_ok,
        "hmac_status": hmac_status,
    }

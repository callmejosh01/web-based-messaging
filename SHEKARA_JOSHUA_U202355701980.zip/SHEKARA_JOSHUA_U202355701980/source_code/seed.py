"""
seed.py
-------
One-time user seeding: generates RSA and ECDH key pairs for Alice, Bob,
and Charlie and inserts them into the database.

Called automatically by app.py at startup. Safe to call repeatedly —
the "if keys already exist, skip" check prevents clobbering stored keys
and breaking messages that were encrypted with the original key pairs.
"""

import sys
from pathlib import Path

# Allow running seed.py directly from project root
# sys.path.insert(0, str(Path(__file__).parent))

from db import database as db
from crypto import rsa_oaep
from crypto import ecdh


SEED_USERS = ["Alice", "Bob", "Charlie"]


def seed_users() -> None:
    """
    Generate and store key pairs for all seed users.
    Skips any user that already exists in the database.
    """
    db.init_db()

    for username in SEED_USERS:
        if db.user_exists(username):
            print(f"[Seed] {username} already exists — skipping.")
            continue

        # RSA-2048 key pair
        rsa_priv, rsa_pub = rsa_oaep.generate_rsa_keypair(key_size=2048)
        rsa_priv_pem = rsa_oaep.serialize_private_key(rsa_priv).decode("ascii")
        rsa_pub_pem  = rsa_oaep.serialize_public_key(rsa_pub).decode("ascii")

        # X25519 (ECDH) key pair
        ecdh_priv, ecdh_pub = ecdh.generate_x25519_keypair()
        ecdh_priv_pem = ecdh.serialize_private_key(ecdh_priv).decode("ascii")
        ecdh_pub_pem  = ecdh.serialize_public_key(ecdh_pub).decode("ascii")

        db.insert_user_keys(
            username=username,
            rsa_public_pem=rsa_pub_pem,
            rsa_private_pem=rsa_priv_pem,
            ecdh_public_pem=ecdh_pub_pem,
            ecdh_private_pem=ecdh_priv_pem,
        )
        print(f"[Seed] {username} — RSA-2048 + X25519 keys generated and stored.")

    print("[Seed] Done.")


if __name__ == "__main__":
    seed_users()

"""
integrity.py
------------
HMAC-SHA256 for message integrity and authentication.

Role in the hybrid system:
    Applied as an EXPLICIT Encrypt-then-MAC layer on top of the AEAD ciphers.
    The MAC is computed over the ciphertext (not the plaintext), meaning
    anyone who tampers with the stored ciphertext blob will fail HMAC
    verification before decryption is even attempted.

    Encrypt-then-MAC ordering is critical:
        WRONG:  MAC(plaintext) then encrypt  → MAC verified on data attacker
                                               never sees; useless.
        WRONG:  Encrypt then MAC(plaintext)  → requires decryption before
                                               verification; padding oracle risk.
        RIGHT:  Encrypt then MAC(ciphertext) → attacker cannot modify
                                               ciphertext without detection,
                                               and we detect it before we
                                               do any decryption work.

    Note: Since AES-GCM and ChaCha20-Poly1305 are both AEAD ciphers, they
    already provide internal integrity via their authentication tags. The
    HMAC layer here is an explicit, auditable, independently-verifiable
    integrity check — demonstrating defence-in-depth and providing a
    visible integrity status in the UI (the ✓ / ✗ display).

Gotcha — Timing attacks on MAC comparison:
    Never compare HMACs with ==. Use hmac.compare_digest(), which runs in
    constant time regardless of where the strings first differ. This prevents
    timing side-channel attacks where an attacker learns how many bytes of
    their forged MAC are correct by measuring response time.

MAC coverage:
    HMAC is computed over: nonce || ciphertext_with_tag
    This binds the nonce to the MAC — an attacker cannot swap nonces across
    messages without invalidating the MAC.
"""

import hmac
import hashlib
import base64


# ---------------------------------------------------------------------------
# HMAC-SHA256 Core
# ---------------------------------------------------------------------------

def compute_hmac(key: bytes, nonce: bytes, ciphertext_with_tag: bytes) -> bytes:
    """
    Compute HMAC-SHA256 over nonce || ciphertext_with_tag.

    Args:
        key:                  The HMAC key. Should be 32 bytes (256 bits).
                              In this system we derive a separate HMAC key
                              from the session key rather than reusing it
                              directly (see derive_hmac_key).
        nonce:                The nonce used during encryption.
        ciphertext_with_tag:  The encrypted bytes including authentication tag.

    Returns:
        32-byte HMAC digest.
    """
    mac = hmac.new(key, digestmod=hashlib.sha256)
    mac.update(nonce)
    mac.update(ciphertext_with_tag)
    return mac.digest()


def verify_hmac(
    key: bytes,
    nonce: bytes,
    ciphertext_with_tag: bytes,
    expected_mac: bytes,
) -> bool:
    """
    Verify HMAC-SHA256 in constant time.

    Args:
        key:                  HMAC key (same key used during compute_hmac).
        nonce:                Nonce stored with the message.
        ciphertext_with_tag:  Ciphertext blob from the database.
        expected_mac:         The stored MAC to compare against.

    Returns:
        True if the MAC is valid (message is intact).
        False if the MAC is invalid (message has been tampered with).
    """
    computed = compute_hmac(key, nonce, ciphertext_with_tag)
    return hmac.compare_digest(computed, expected_mac)


# ---------------------------------------------------------------------------
# HMAC Key Derivation
# ---------------------------------------------------------------------------

def derive_hmac_key(session_key: bytes) -> bytes:
    """
    Derive a dedicated HMAC key from the session key.

    Using the session key directly as both the encryption key and HMAC key
    is a key-reuse pattern that can weaken security in subtle ways. Instead,
    we derive a separate HMAC key by hashing the session key with a
    domain-separation label.

    This is a lightweight alternative to running a full second HKDF pass.
    For this demonstration context it is appropriate; in production you would
    use HKDF with a distinct 'info' label for the HMAC key.

    Args:
        session_key:  The 32-byte symmetric session key from key exchange.

    Returns:
        32-byte HMAC key.
    """
    label = b"hmac-key-derivation-v1"
    return hashlib.sha256(label + session_key).digest()


# ---------------------------------------------------------------------------
# Storage helpers
# ---------------------------------------------------------------------------

def encode_mac_for_storage(mac_bytes: bytes) -> str:
    """Encode HMAC bytes to base64 string for SQLite TEXT storage."""
    return base64.b64encode(mac_bytes).decode("ascii")


def decode_mac_from_storage(b64_string: str) -> bytes:
    """Decode HMAC from base64 string back to raw bytes."""
    return base64.b64decode(b64_string.encode("ascii"))

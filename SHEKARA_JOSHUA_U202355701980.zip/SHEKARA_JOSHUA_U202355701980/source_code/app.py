"""
app.py
------
Flask application entry point and route definitions.
Kept intentionally flat (no Blueprint split) since the route surface
is small. Routes import crypto_engine and database only — never raw
crypto modules directly.
"""

from flask import Flask, render_template, request, jsonify
from db import database as db
import crypto_engine as engine
import seed

app = Flask(__name__)


# ---------------------------------------------------------------------------
# Startup
# ---------------------------------------------------------------------------

def initialise():
    """Init DB schema and seed users on first run."""
    seed.seed_users()


# ---------------------------------------------------------------------------
# Main page
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    usernames = db.get_all_usernames()
    algo_combos = [
        {"label": "RSA-OAEP + AES-GCM",          "ke": "RSA-OAEP", "sym": "AES-GCM"},
        {"label": "RSA-OAEP + ChaCha20-Poly1305", "ke": "RSA-OAEP", "sym": "ChaCha20-Poly1305"},
        {"label": "ECDH + AES-GCM",               "ke": "ECDH",     "sym": "AES-GCM"},
        {"label": "ECDH + ChaCha20-Poly1305",      "ke": "ECDH",     "sym": "ChaCha20-Poly1305"},
    ]
    return render_template("index.html", usernames=usernames, algo_combos=algo_combos)


# ---------------------------------------------------------------------------
# Send a message
# ---------------------------------------------------------------------------

@app.route("/send", methods=["POST"])
def send_message():
    """
    Encrypt and persist a message.

    Expects JSON body:
        {
            "sender":      "Alice",
            "recipient":   "Bob",
            "plaintext":   "Hello Bob",
            "ke_algo":     "RSA-OAEP",
            "sym_algo":    "AES-GCM"
        }

    Returns JSON:
        { "ok": true, "message_id": <int> }
    """
    data = request.get_json(force=True)

    sender    = data.get("sender", "").strip()
    recipient = data.get("recipient", "").strip()
    plaintext = data.get("plaintext", "").strip()
    ke_algo   = data.get("ke_algo", "RSA-OAEP")
    sym_algo  = data.get("sym_algo", "AES-GCM")

    # Basic validation
    if not plaintext:
        return jsonify({"ok": False, "error": "Message cannot be empty."}), 400
    if sender == recipient:
        return jsonify({"ok": False, "error": "Sender and recipient must differ."}), 400

    recipient_row = db.get_user_keys(recipient)
    if not recipient_row:
        return jsonify({"ok": False, "error": f"Unknown recipient: {recipient}"}), 404

    # Encrypt
    bundle = engine.encrypt_message(
        plaintext=plaintext,
        sender=sender,
        recipient_row=recipient_row,
        key_exchange_algo=ke_algo,
        symmetric_algo=sym_algo,
    )

    # Persist
    message_id = db.insert_message(
        sender=bundle["sender"],
        recipient=bundle["recipient"],
        symmetric_algo=bundle["symmetric_algo"],
        key_exchange_algo=bundle["key_exchange_algo"],
        nonce_b64=bundle["nonce_b64"],
        ciphertext_b64=bundle["ciphertext_b64"],
        hmac_b64=bundle["hmac_b64"],
        wrapped_session_key_b64=bundle["wrapped_session_key_b64"],
    )

    if bundle["key_exchange_algo"] == "ECDH":
        db.insert_key_exchange_log(
            message_id=message_id,
            ephemeral_pub_key_pem=bundle["ephemeral_pub_key_pem"],
            hkdf_salt_b64=bundle["hkdf_salt_b64"],
        )

    return jsonify({"ok": True, "message_id": message_id})


# ---------------------------------------------------------------------------
# Fetch and decrypt conversation
# ---------------------------------------------------------------------------

@app.route("/conversation")
def get_conversation():
    """
    Return all messages between two users, with decrypted plaintext.

    Query params:
        user_a  — the active "I am" user (perspective)
        user_b  — the other participant

    Returns JSON array of message objects, each with:
        id, sender, recipient, symmetric_algo, key_exchange_algo,
        ciphertext_b64, nonce_b64, hmac_b64, timestamp,
        plaintext, hmac_ok, hmac_status,
        ephemeral_pub_key_pem (or null), hkdf_salt_b64 (or null)
    """
    user_a = request.args.get("user_a", "").strip()
    user_b = request.args.get("user_b", "").strip()

    if not user_a or not user_b:
        return jsonify([])

    messages   = db.get_conversation(user_a, user_b)
    user_a_row = db.get_user_keys(user_a)
    user_b_row = db.get_user_keys(user_b)

    result = []
    for msg in messages:
        # Determine which user's private key to use for decryption
        recipient_row = user_b_row if msg["recipient"] == user_b else user_a_row

        decrypted = engine.decrypt_message(msg, recipient_row)

        result.append({
            "id":                    msg["id"],
            "sender":                msg["sender"],
            "recipient":             msg["recipient"],
            "symmetric_algo":        msg["symmetric_algo"],
            "key_exchange_algo":     msg["key_exchange_algo"],
            "ciphertext_b64":        msg["ciphertext_b64"],
            "nonce_b64":             msg["nonce_b64"],
            "hmac_b64":              msg["hmac_b64"],
            "timestamp":             msg["timestamp"],
            "plaintext":             decrypted["plaintext"],
            "hmac_ok":               decrypted["hmac_ok"],
            "hmac_status":           decrypted["hmac_status"],
            "ephemeral_pub_key_pem": msg["ephemeral_pub_key_pem"],
            "hkdf_salt_b64":         msg["hkdf_salt_b64"],
        })

    return jsonify(result)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    initialise()
    app.run(debug=True, port=5000)
